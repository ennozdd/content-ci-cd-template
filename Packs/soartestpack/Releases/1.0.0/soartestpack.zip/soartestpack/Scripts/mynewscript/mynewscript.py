demisto.executeCommand('Print', {'value': 'EnesTest'})


if __name__ in ('__main__', '__builtin__', 'builtins'):
    main()
